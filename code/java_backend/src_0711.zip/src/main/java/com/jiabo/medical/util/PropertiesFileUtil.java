package com.jiabo.medical.util;


public class PropertiesFileUtil {
	public static String getProperty(String file) {
		return null;
	}
}
